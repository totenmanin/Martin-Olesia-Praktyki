from datetime import date, datetime, timezone

import pytest

from app.market import UINT32_MAX, clamp_volume, from_scaled, session_closed, to_scaled


def test_scaling_roundtrip():
    assert to_scaled(189.5) == 1_895_000
    assert from_scaled(to_scaled(12.3456)) == 12.3456


def test_scaling_out_of_range():
    with pytest.raises(ValueError):
        to_scaled(-1)
    with pytest.raises(ValueError):
        to_scaled(10_000_000)


def test_clamp_volume():
    assert clamp_volume(5_000_000_000) == UINT32_MAX
    assert clamp_volume(1234) == 1234


def test_session_closed():
    after_close = datetime(2026, 10, 21, 21, 0, tzinfo=timezone.utc)   # 17:00 w Nowym Jorku
    during = datetime(2026, 10, 21, 17, 0, tzinfo=timezone.utc)        # 13:00 w Nowym Jorku
    assert session_closed(date(2026, 10, 20), during)       # wczorajsza sesja - zakończona
    assert not session_closed(date(2026, 10, 21), during)   # dzisiejsza w trakcie
    assert session_closed(date(2026, 10, 21), after_close)  # dzisiejsza po zamknięciu
