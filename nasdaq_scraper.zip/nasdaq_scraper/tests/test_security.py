import pytest

from app.security import SlidingWindow, find_client, hash_key, parse_clients


def test_find_client_accepts_correct_key():
    clients = {"jan": hash_key("tajny-klucz")}
    assert find_client("tajny-klucz", clients) == "jan"


def test_find_client_rejects_wrong_or_missing_key():
    clients = {"jan": hash_key("tajny-klucz")}
    assert find_client("zly", clients) is None
    assert find_client(None, clients) is None
    assert find_client("", clients) is None


def test_non_ascii_key_does_not_crash():
    # w starej wersji compare_digest rzucał TypeError przy znakach spoza ASCII
    assert find_client("klucz-żółw", {"jan": hash_key("a")}) is None


def test_parse_clients_ok_and_bad_format():
    h = hash_key("x")
    assert parse_clients(f"jan:{h}, ola:{h}") == {"jan": h, "ola": h}
    assert parse_clients("") == {}
    with pytest.raises(ValueError):
        parse_clients("jan:za-krotki")


def test_sliding_window_limits():
    w = SlidingWindow(limit=3, window_seconds=60)
    for _ in range(3):
        assert not w.is_full("a")
        w.add("a")
    assert w.is_full("a")
    assert not w.is_full("b")      # inny klucz ma własny limit
