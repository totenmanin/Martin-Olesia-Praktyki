from datetime import date, timedelta

from app.patterns import (
    BIG_DROP, BIG_RISE, BREAKOUT_DOWN, BREAKOUT_UP, GAP_DOWN, GAP_UP, SMA_CROSS_DOWN,
    SMA_CROSS_UP, STREAK_DOWN, STREAK_UP, VOLUME_SPIKE, Bar, PatternParams, analyse,
    current_streak, detect_patterns, rsi,
)

P = PatternParams()


def make(closes, volume=1000, opens=None):
    bars = []
    for i, c in enumerate(closes):
        o = opens[i] if opens else (closes[i - 1] if i else c)
        bars.append(Bar(date(2025, 1, 1) + timedelta(days=i), o, max(o, c) + 1, min(o, c) - 1, c,
                        volume[i] if isinstance(volume, list) else volume))
    return bars


def codes_over_time(bars):
    return [{c for c, _ in detect_patterns(bars[: i + 1], P)} for i in range(len(bars))]


def last_codes(bars):
    return {c for c, _ in detect_patterns(bars, P)}


def test_big_rise_and_drop():
    assert BIG_RISE in last_codes(make([100, 100, 104]))
    assert BIG_RISE not in last_codes(make([100, 100, 102]))
    assert BIG_DROP in last_codes(make([100, 100, 96]))


def test_gap_up_and_down():
    assert GAP_UP in last_codes(make([100, 103], opens=[100, 103]))
    assert GAP_DOWN in last_codes(make([100, 97], opens=[100, 97]))
    assert GAP_UP not in last_codes(make([100, 101], opens=[100, 100.5]))


def test_streak_up_exactly_when_length_reached():
    events = codes_over_time(make([100, 101, 102, 103, 104, 105, 106]))
    assert STREAK_UP in events[5]          # 5 wzrostów z rzędu
    assert STREAK_UP not in events[6]      # zdarzenia nie powtarzamy


def test_streak_down():
    assert STREAK_DOWN in codes_over_time(make([110, 109, 108, 107, 106, 105]))[5]


def test_current_streak():
    assert current_streak([1, 2, 3]) == 2
    assert current_streak([3, 2]) == -1
    assert current_streak([1, 1]) == 0


def test_sma_cross_up_and_down():
    up = [200 - i for i in range(60)] + [141 + 3 * i for i in range(40)]
    down = [100 + i for i in range(60)] + [159 - 3 * i for i in range(40)]
    assert any(SMA_CROSS_UP in e for e in codes_over_time(make(up)))
    assert any(SMA_CROSS_DOWN in e for e in codes_over_time(make(down)))


def test_no_sma_cross_down_in_monotonic_rise():
    assert not any(SMA_CROSS_DOWN in e for e in codes_over_time(make([100 + i for i in range(80)])))


def test_breakout_up_and_down():
    flat = [100.0] * 25
    assert BREAKOUT_UP in last_codes(make(flat + [110.0]))
    assert BREAKOUT_DOWN in last_codes(make(flat + [90.0]))


def test_volume_spike():
    closes = [100.0] * 25
    assert VOLUME_SPIKE in last_codes(make(closes, volume=[1000] * 24 + [3000]))
    assert VOLUME_SPIKE not in last_codes(make(closes, volume=[1000] * 25))


def test_rsi():
    assert rsi([float(i) for i in range(1, 40)]) == 100.0
    assert rsi([1.0, 2.0]) is None


def test_no_patterns_with_too_little_data():
    assert detect_patterns(make([100.0]), P) == []


def test_analyse_trend_up():
    info = analyse(make([100 + i for i in range(80)]), P)
    assert info["trend"] == "UP" and info["change_1d_pct"] > 0 and info["streak"] == 79


def test_analyse_unknown_with_little_data():
    assert analyse(make([100.0, 101.0, 102.0]), P)["trend"] == "UNKNOWN"
