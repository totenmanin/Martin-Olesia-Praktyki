from datetime import date

from pydantic import BaseModel


class StockOut(BaseModel):
    ticker: str
    name: str | None


class PriceOut(BaseModel):
    trade_date: date
    open: float
    high: float
    low: float
    close: float
    volume: int


class LatestOut(PriceOut):
    ticker: str


class PatternOut(BaseModel):
    trade_date: date
    pattern: str
    value: float | None


class AnalysisOut(BaseModel):
    ticker: str
    trade_date: date
    samples: int
    data_age_days: int      # ile dni temu była ostatnia zapisana sesja
    close: float
    trend: str
    sma_fast: float | None
    sma_slow: float | None
    rsi: float | None
    streak: int
    change_1d_pct: float | None
    change_5d_pct: float | None
    change_20d_pct: float | None
    patterns: list[str]
    note: str = "Prosta analiza historyczna - nie jest poradą inwestycyjną."


class HealthOut(BaseModel):
    status: str
