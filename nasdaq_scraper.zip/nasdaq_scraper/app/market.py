"""Małe funkcje pomocnicze bez zależności (łatwe do testów)."""
from datetime import date, datetime, time
from zoneinfo import ZoneInfo

PRICE_SCALE = 10_000            # cena w bazie = cena * 10000 (liczba całkowita, 4 B, bez błędów zaokrągleń)
UINT32_MAX = 4_294_967_295
NY = ZoneInfo("America/New_York")


def to_scaled(price) -> int:
    """12.3456 -> 123456. Rzuca ValueError, gdy cena nie mieści się w INT UNSIGNED."""
    value = int(round(float(price) * PRICE_SCALE))
    if value < 0 or value > UINT32_MAX:
        raise ValueError(f"Cena poza zakresem: {price}")
    return value


def from_scaled(value: int) -> float:
    return round(value / PRICE_SCALE, 4)


def clamp_volume(volume) -> int:
    return max(0, min(int(volume), UINT32_MAX))


def session_closed(day: date, now: datetime | None = None) -> bool:
    """Czy sesja z danego dnia jest już zakończona (giełda w Nowym Jorku zamyka się o 16:00).

    Dzięki temu nie zapisujemy niepełnej, dzisiejszej świecy.
    """
    now = now.astimezone(NY) if now else datetime.now(NY)
    if day < now.date():
        return True
    if day > now.date():
        return False
    return now.time() >= time(16, 15)
