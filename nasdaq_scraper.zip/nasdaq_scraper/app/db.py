"""Połączenie z bazą MySQL/MariaDB (pula połączeń). Zapytania: app/queries.py, schemat: db/01-schema.sql."""
from functools import lru_cache

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from app.config import settings


@lru_cache
def get_engine() -> Engine:
    return create_engine(settings.database_url, pool_pre_ping=True, pool_recycle=1800,
                         pool_size=5, max_overflow=5)
