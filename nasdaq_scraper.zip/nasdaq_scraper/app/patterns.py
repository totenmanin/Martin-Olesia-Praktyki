"""Wykrywanie wzorców wzrostu i spadku na dziennych notowaniach.

Plik nie zna bazy ani internetu: dostaje listę sesji (Bar), zwraca wynik.
"""
from dataclasses import dataclass
from datetime import date
from typing import NamedTuple

# Kody wzorców zapisujemy w bazie jako małe liczby (1 bajt zamiast tekstu)
STREAK_UP = 1
STREAK_DOWN = 2
SMA_CROSS_UP = 3
SMA_CROSS_DOWN = 4
BREAKOUT_UP = 5
BREAKOUT_DOWN = 6
BIG_RISE = 7
BIG_DROP = 8
GAP_UP = 9
GAP_DOWN = 10
VOLUME_SPIKE = 11
RSI_OVERBOUGHT = 12
RSI_OVERSOLD = 13

PATTERN_NAMES = {
    STREAK_UP: "STREAK_UP",            # seria kolejnych wzrostów
    STREAK_DOWN: "STREAK_DOWN",        # seria kolejnych spadków
    SMA_CROSS_UP: "SMA_CROSS_UP",      # szybka średnia przebija wolną w górę
    SMA_CROSS_DOWN: "SMA_CROSS_DOWN",  # ... w dół
    BREAKOUT_UP: "BREAKOUT_UP",        # zamknięcie ponad maksimum z ostatnich N sesji
    BREAKOUT_DOWN: "BREAKOUT_DOWN",    # zamknięcie poniżej minimum z ostatnich N sesji
    BIG_RISE: "BIG_RISE",              # duży dzienny wzrost (domyślnie >= 3%)
    BIG_DROP: "BIG_DROP",              # duży dzienny spadek
    GAP_UP: "GAP_UP",                  # otwarcie wyraźnie powyżej wczorajszego zamknięcia
    GAP_DOWN: "GAP_DOWN",
    VOLUME_SPIKE: "VOLUME_SPIKE",      # wolumen znacznie ponad średnią
    RSI_OVERBOUGHT: "RSI_OVERBOUGHT",
    RSI_OVERSOLD: "RSI_OVERSOLD",
}


class Bar(NamedTuple):
    """Jedna sesja dzienna (OHLCV), ceny jako zwykłe liczby (np. 189.5)."""
    day: date
    open: float
    high: float
    low: float
    close: float
    volume: int


@dataclass(frozen=True)
class PatternParams:
    streak_length: int = 5
    big_move_pct: float = 3.0
    gap_pct: float = 2.0
    sma_fast: int = 20
    sma_slow: int = 50
    breakout_lookback: int = 20
    volume_lookback: int = 20
    volume_spike_ratio: float = 2.0
    rsi_period: int = 14
    rsi_high: float = 70.0
    rsi_low: float = 30.0


def sma(values: list[float], period: int, end: int) -> float | None:
    """Średnia z `period` wartości kończących się na indeksie `end`."""
    start = end - period + 1
    if start < 0:
        return None
    return sum(values[start:end + 1]) / period


def rsi(closes: list[float], period: int = 14) -> float | None:
    """RSI (metoda Wildera). None, gdy za mało danych."""
    if len(closes) < period + 1:
        return None
    gains = losses = 0.0
    for i in range(1, period + 1):
        diff = closes[i] - closes[i - 1]
        if diff >= 0:
            gains += diff
        else:
            losses -= diff
    avg_gain, avg_loss = gains / period, losses / period
    for i in range(period + 1, len(closes)):
        diff = closes[i] - closes[i - 1]
        avg_gain = (avg_gain * (period - 1) + max(diff, 0.0)) / period
        avg_loss = (avg_loss * (period - 1) + max(-diff, 0.0)) / period
    if avg_loss == 0:
        return 100.0 if avg_gain > 0 else 50.0
    return 100 - 100 / (1 + avg_gain / avg_loss)


def current_streak(closes: list[float]) -> int:
    """Ile ostatnich sesji z rzędu rośnie (liczba dodatnia) lub spada (ujemna)."""
    if len(closes) < 2:
        return 0
    diff = closes[-1] - closes[-2]
    if diff == 0:
        return 0
    direction = 1 if diff > 0 else -1
    count = 0
    for i in range(len(closes) - 1, 0, -1):
        step = closes[i] - closes[i - 1]
        if (step > 0 and direction == 1) or (step < 0 and direction == -1):
            count += 1
        else:
            break
    return count * direction


def pct_change(closes: list[float], periods: int) -> float | None:
    if len(closes) <= periods:
        return None
    old = closes[-1 - periods]
    return None if old == 0 else (closes[-1] / old - 1) * 100


def detect_patterns(bars: list[Bar], p: PatternParams) -> list[tuple[int, float]]:
    """Sprawdza, czy NA OSTATNIEJ sesji zaczął się jakiś wzorzec.

    Zwraca listę (kod_wzorca, wartość). Zapisujemy tylko zdarzenia - tabela signals jest mała.
    """
    found: list[tuple[int, float]] = []
    n = len(bars)
    if n < 2:
        return found
    closes = [b.close for b in bars]
    last, prev = bars[-1], bars[-2]

    # 1) Duży dzienny ruch i luka przy otwarciu
    if prev.close > 0:
        change = (last.close / prev.close - 1) * 100
        if change >= p.big_move_pct:
            found.append((BIG_RISE, change))
        elif change <= -p.big_move_pct:
            found.append((BIG_DROP, change))
        gap = (last.open / prev.close - 1) * 100
        if gap >= p.gap_pct:
            found.append((GAP_UP, gap))
        elif gap <= -p.gap_pct:
            found.append((GAP_DOWN, gap))

    # 2) Seria wzrostów / spadków (zdarzenie w chwili osiągnięcia zadanej długości)
    streak = current_streak(closes)
    if streak == p.streak_length:
        found.append((STREAK_UP, pct_change(closes, p.streak_length) or 0.0))
    elif streak == -p.streak_length:
        found.append((STREAK_DOWN, pct_change(closes, p.streak_length) or 0.0))

    # 3) Przecięcie średnich SMA
    if n >= p.sma_slow + 1:
        f_now, s_now = sma(closes, p.sma_fast, n - 1), sma(closes, p.sma_slow, n - 1)
        f_prev, s_prev = sma(closes, p.sma_fast, n - 2), sma(closes, p.sma_slow, n - 2)
        if None not in (f_now, s_now, f_prev, s_prev):
            before, now = f_prev - s_prev, f_now - s_now
            gap_pct = now / s_now * 100
            if before <= 0 < now:
                found.append((SMA_CROSS_UP, gap_pct))
            elif before >= 0 > now:
                found.append((SMA_CROSS_DOWN, gap_pct))

    # 4) Wybicie ponad maksimum / poniżej minimum z ostatnich N sesji
    if n >= p.breakout_lookback + 1:
        previous = bars[-1 - p.breakout_lookback:-1]
        highest = max(b.high for b in previous)
        lowest = min(b.low for b in previous)
        if last.close > highest:
            found.append((BREAKOUT_UP, (last.close / highest - 1) * 100))
        elif last.close < lowest:
            found.append((BREAKOUT_DOWN, (last.close / lowest - 1) * 100))

    # 5) Skok wolumenu względem średniej
    if n >= p.volume_lookback + 1:
        previous = bars[-1 - p.volume_lookback:-1]
        avg_volume = sum(b.volume for b in previous) / p.volume_lookback
        if avg_volume > 0 and last.volume >= p.volume_spike_ratio * avg_volume:
            found.append((VOLUME_SPIKE, last.volume / avg_volume))

    # 6) RSI wchodzi w strefę wykupienia / wyprzedania
    if n >= p.rsi_period + 2:
        rsi_now, rsi_before = rsi(closes, p.rsi_period), rsi(closes[:-1], p.rsi_period)
        if rsi_now is not None and rsi_before is not None:
            if rsi_before < p.rsi_high <= rsi_now:
                found.append((RSI_OVERBOUGHT, rsi_now))
            elif rsi_before > p.rsi_low >= rsi_now:
                found.append((RSI_OVERSOLD, rsi_now))

    return found


def _round(value: float | None, digits: int = 4) -> float | None:
    return None if value is None else round(value, digits)


def analyse(bars: list[Bar], p: PatternParams) -> dict:
    """Aktualny stan spółki (używa go endpoint /analysis)."""
    closes = [b.close for b in bars]
    n = len(closes)
    fast = sma(closes, p.sma_fast, n - 1)
    slow = sma(closes, p.sma_slow, n - 1)
    trend = "UNKNOWN"
    if fast is not None and slow is not None:
        if fast > slow * 1.001:
            trend = "UP"
        elif fast < slow * 0.999:
            trend = "DOWN"
        else:
            trend = "SIDEWAYS"
    return {
        "close": closes[-1],
        "trend": trend,
        "sma_fast": _round(fast),
        "sma_slow": _round(slow),
        "rsi": _round(rsi(closes, p.rsi_period), 2),
        "streak": current_streak(closes),
        "change_1d_pct": _round(pct_change(closes, 1)),
        "change_5d_pct": _round(pct_change(closes, 5)),
        "change_20d_pct": _round(pct_change(closes, 20)),
    }
