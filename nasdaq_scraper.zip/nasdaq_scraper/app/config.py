"""Ustawienia aplikacji - wczytywane ze zmiennych środowiskowych lub pliku .env."""
import re
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.engine import URL

from app.patterns import PatternParams

TICKER_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9.\-]{0,15}$"
TICKER_RE = re.compile(r"^[A-Z0-9][A-Z0-9.\-]{0,15}$")

DEFAULT_SYMBOLS = (
    "AAPL,MSFT,NVDA,AMZN,GOOGL,META,TSLA,AVGO,COST,NFLX,AMD,ADBE,PEP,CSCO,INTC,"
    "QCOM,TXN,AMGN,INTU,CMCSA,HON,AMAT,SBUX,ISRG,BKNG,MU,LRCX,ADI,PANW,GILD"
)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Nasdaq Market API"

    # --- baza danych (collector i API używają różnych użytkowników) ---
    db_host: str = "127.0.0.1"
    db_port: int = 3306
    db_name: str = "nasdaq_db"
    db_user: str = ""
    db_password: str = ""

    # --- collector ---
    symbols: str = ""                    # puste = DEFAULT_SYMBOLS
    history_period: Literal["3mo", "6mo", "1y", "2y", "5y", "10y", "max"] = "1y"
    run_at_utc: str = "22:30"            # tryb --daemon: o której godzinie (UTC) pobierać dane
    request_pause_seconds: float = 1.0   # pauza między spółkami (nie przeciążamy Yahoo)
    analysis_window: int = 300           # ile ostatnich sesji bierzemy do analizy

    # --- wzorce ---
    streak_length: int = 5
    big_move_pct: float = 3.0
    gap_pct: float = 2.0
    sma_fast: int = 20
    sma_slow: int = 50
    breakout_lookback: int = 20
    volume_lookback: int = 20
    volume_spike_ratio: float = 2.0
    rsi_period: int = 14
    rsi_high: float = 70.0
    rsi_low: float = 30.0

    # --- API ---
    api_keys: str = ""                   # format: nazwa:sha256,nazwa2:sha256
    rate_limit_per_minute: int = 60
    enable_docs: bool = False

    @property
    def symbol_list(self) -> list[str]:
        raw = self.symbols.strip() or DEFAULT_SYMBOLS
        result = []
        for item in raw.split(","):
            ticker = item.strip().upper()
            if not ticker:
                continue
            if not TICKER_RE.match(ticker):
                raise ValueError(f"Niepoprawny symbol w SYMBOLS: {ticker!r}")
            result.append(ticker)
        return result

    @property
    def database_url(self) -> URL:
        return URL.create(
            "mysql+pymysql",
            username=self.db_user, password=self.db_password,
            host=self.db_host, port=self.db_port, database=self.db_name,
            query={"charset": "utf8mb4"},
        )

    @property
    def pattern_params(self) -> PatternParams:
        return PatternParams(
            streak_length=self.streak_length, big_move_pct=self.big_move_pct, gap_pct=self.gap_pct,
            sma_fast=self.sma_fast, sma_slow=self.sma_slow, breakout_lookback=self.breakout_lookback,
            volume_lookback=self.volume_lookback, volume_spike_ratio=self.volume_spike_ratio,
            rsi_period=self.rsi_period, rsi_high=self.rsi_high, rsi_low=self.rsi_low,
        )


settings = Settings()
