"""Uwierzytelnianie kluczem API oraz proste limity zapytań."""
import hashlib
import hmac
import time
from collections import defaultdict, deque

from fastapi import Header, HTTPException, Request, status

from app.config import settings


def hash_key(key: str) -> str:
    """W konfiguracji trzymamy tylko hash klucza, nigdy sam klucz."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def parse_clients(raw: str) -> dict[str, str]:
    """'jan:abc...,ola:def...' -> {'jan': 'abc...', 'ola': 'def...'} (nazwa -> hash)."""
    clients: dict[str, str] = {}
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        name, sep, key_hash = part.partition(":")
        name, key_hash = name.strip(), key_hash.strip().lower()
        if not sep or not name or len(key_hash) != 64:
            raise ValueError("Zły format API_KEYS - oczekiwano nazwa:hash_sha256")
        clients[name] = key_hash
    return clients


def find_client(key: str | None, clients: dict[str, str]) -> str | None:
    """Zwraca nazwę klienta albo None. Porównanie odporne na ataki czasowe."""
    if not key:
        return None
    given = hash_key(key)
    found = None
    for name, key_hash in clients.items():   # nie przerywamy pętli wcześniej
        if hmac.compare_digest(given, key_hash):
            found = name
    return found


class SlidingWindow:
    """Limit: maksymalnie `limit` zdarzeń w ciągu `window_seconds` dla danego klucza."""

    def __init__(self, limit: int, window_seconds: int = 60) -> None:
        self.limit = limit
        self.window = window_seconds
        self.hits: dict[str, deque[float]] = defaultdict(deque)

    def _purge(self, key: str) -> deque[float]:
        q = self.hits[key]
        now = time.monotonic()
        while q and now - q[0] > self.window:
            q.popleft()
        if not q:
            self.hits.pop(key, None)
        return q

    def is_full(self, key: str) -> bool:
        return len(self._purge(key)) >= self.limit

    def add(self, key: str) -> None:
        self.hits[key].append(time.monotonic())


# UWAGA: limity są w pamięci jednego procesu - dlatego API uruchamiamy z 1 workerem.
_clients: dict[str, str] = {}
_rate = SlidingWindow(settings.rate_limit_per_minute, 60)
_failed_logins = SlidingWindow(10, 60)


def init_clients(raw: str) -> None:
    _clients.clear()
    _clients.update(parse_clients(raw))
    if not _clients:
        raise RuntimeError("API_KEYS jest puste - wygeneruj klucz: python scripts/make_api_key.py")


async def require_api_key(request: Request, x_api_key: str | None = Header(default=None)) -> str:
    ip = request.client.host if request.client else "unknown"
    if _failed_logins.is_full(ip):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Zbyt wiele błędnych prób.",
                            headers={"Retry-After": "60"})

    client = find_client(x_api_key, _clients)
    if client is None:
        _failed_logins.add(ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Brak lub nieprawidłowy klucz API.",
                            headers={"WWW-Authenticate": "ApiKey"})

    if _rate.is_full(client):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Przekroczono limit zapytań.",
                            headers={"Retry-After": "60"})
    _rate.add(client)
    return client
