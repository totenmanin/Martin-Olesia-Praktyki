"""Wszystkie zapytania SQL w jednym miejscu (czysty SQL, bez ORM).

Parametry :nazwa są podstawiane bezpiecznie (brak SQL injection).
Ceny w bazie to cena * 10000 (liczby całkowite) - przeliczamy je w Pythonie.
"""
from sqlalchemy import text

# ---------- spółki ----------
# Nazwa spółki uzupełniana tylko, gdy jej jeszcze nie ma (COALESCE)
INSERT_STOCK = text("""
    INSERT INTO stocks (ticker, name) VALUES (:ticker, :name)
    ON DUPLICATE KEY UPDATE name = COALESCE(name, VALUES(name))
""")
SELECT_STOCK_ID = text("SELECT id FROM stocks WHERE ticker = :ticker")
SELECT_STOCK_NAME = text("SELECT name FROM stocks WHERE ticker = :ticker")
SELECT_STOCKS = text("SELECT ticker, name FROM stocks ORDER BY ticker")

# ---------- zapis (collector) ----------
SELECT_LAST_DATE = text("SELECT MAX(trade_date) FROM daily_prices WHERE stock_id = :stock_id")

# Upsert: nowa sesja = INSERT, istniejąca = nadpisanie (np. po splicie akcji)
UPSERT_PRICE = text("""
    INSERT INTO daily_prices
        (stock_id, trade_date, open_price, high_price, low_price, close_price, volume)
    VALUES
        (:stock_id, :trade_date, :open_price, :high_price, :low_price, :close_price, :volume)
    ON DUPLICATE KEY UPDATE
        open_price = VALUES(open_price), high_price = VALUES(high_price),
        low_price = VALUES(low_price), close_price = VALUES(close_price),
        volume = VALUES(volume)
""")

INSERT_SIGNAL = text("""
    INSERT IGNORE INTO signals (stock_id, trade_date, pattern, value)
    VALUES (:stock_id, :trade_date, :pattern, :value)
""")

# ---------- odczyt (API) ----------
SELECT_RECENT_BARS = text("""
    SELECT trade_date, open_price, high_price, low_price, close_price, volume
    FROM daily_prices
    WHERE stock_id = :stock_id
    ORDER BY trade_date DESC
    LIMIT :limit
""")

LATEST_ALL = text("""
    SELECT s.ticker, p.trade_date, p.open_price, p.high_price, p.low_price, p.close_price, p.volume
    FROM daily_prices AS p
    JOIN (
        SELECT stock_id, MAX(trade_date) AS trade_date
        FROM daily_prices
        GROUP BY stock_id
    ) AS newest ON newest.stock_id = p.stock_id AND newest.trade_date = p.trade_date
    JOIN stocks AS s ON s.id = p.stock_id
    ORDER BY s.ticker
""")

LATEST_ONE = text("""
    SELECT s.ticker, p.trade_date, p.open_price, p.high_price, p.low_price, p.close_price, p.volume
    FROM daily_prices AS p
    JOIN stocks AS s ON s.id = p.stock_id
    WHERE p.stock_id = :stock_id
    ORDER BY p.trade_date DESC
    LIMIT 1
""")

PRICES_HISTORY = text("""
    SELECT trade_date, open_price, high_price, low_price, close_price, volume
    FROM daily_prices
    WHERE stock_id = :stock_id
      AND (:start IS NULL OR trade_date >= :start)
      AND (:end IS NULL OR trade_date <= :end)
    ORDER BY trade_date DESC
    LIMIT :limit
""")

SIGNALS_HISTORY = text("""
    SELECT trade_date, pattern, value
    FROM signals
    WHERE stock_id = :stock_id
      AND (:start IS NULL OR trade_date >= :start)
      AND (:end IS NULL OR trade_date <= :end)
    ORDER BY trade_date DESC, pattern
    LIMIT :limit
""")

HEALTH_CHECK = text("SELECT 1")
