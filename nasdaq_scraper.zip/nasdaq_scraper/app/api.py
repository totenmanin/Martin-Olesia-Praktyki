"""API tylko do odczytu. Uruchomienie: uvicorn app.api:app"""
import logging
from contextlib import asynccontextmanager
from datetime import date
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Path, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy.engine import Connection
from sqlalchemy.exc import SQLAlchemyError

from app import queries as q
from app.config import TICKER_PATTERN, settings
from app.db import get_engine
from app.market import from_scaled
from app.patterns import PATTERN_NAMES, Bar, analyse, detect_patterns
from app.schemas import AnalysisOut, HealthOut, LatestOut, PatternOut, PriceOut, StockOut
from app.security import init_clients, require_api_key

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("api")

TickerPath = Annotated[str, Path(pattern=TICKER_PATTERN, description="np. AAPL")]


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_clients(settings.api_keys)       # przerywa start, jeśli nie ma kluczy
    yield


app = FastAPI(
    title=settings.app_name,
    version="2.0.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.enable_docs else None,
    redoc_url=None,
    openapi_url="/openapi.json" if settings.enable_docs else None,
)


@app.exception_handler(SQLAlchemyError)
async def database_error_handler(request: Request, exc: SQLAlchemyError):
    logger.error("Błąd bazy danych", exc_info=exc)       # szczegóły tylko w logach
    return JSONResponse(status_code=503, content={"detail": "Baza danych chwilowo niedostępna."})


def get_conn():
    with get_engine().connect() as conn:
        yield conn


def get_stock_id(conn: Connection, ticker: str) -> int:
    row = conn.execute(q.SELECT_STOCK_ID, {"ticker": ticker.upper()}).first()
    if row is None:
        raise HTTPException(status_code=404, detail="Nieznany symbol.")
    return row[0]


def price_out(row) -> PriceOut:
    day, o, h, l, c, v = row
    return PriceOut(trade_date=day, open=from_scaled(o), high=from_scaled(h),
                    low=from_scaled(l), close=from_scaled(c), volume=v)


def check_range(start: date | None, end: date | None) -> None:
    if start and end and start > end:
        raise HTTPException(status_code=422, detail="start_date nie może być późniejsza niż end_date.")


@app.get("/health", response_model=HealthOut, tags=["Status"])
def health(conn: Connection = Depends(get_conn)):
    conn.execute(q.HEALTH_CHECK)
    return HealthOut(status="ok")


@app.get("/api/v1/stocks", response_model=list[StockOut], tags=["Info"],
         dependencies=[Depends(require_api_key)])
def list_stocks(conn: Connection = Depends(get_conn)):
    return [StockOut(ticker=t, name=n) for t, n in conn.execute(q.SELECT_STOCKS)]


@app.get("/api/v1/prices/latest", response_model=list[LatestOut], tags=["Ceny"],
         dependencies=[Depends(require_api_key)])
def latest_prices(
    ticker: Annotated[str | None, Query(pattern=TICKER_PATTERN)] = None,
    conn: Connection = Depends(get_conn),
):
    """Ostatnia sesja każdej spółki (lub jednej, gdy podano ?ticker=)."""
    if ticker:
        rows = conn.execute(q.LATEST_ONE, {"stock_id": get_stock_id(conn, ticker)}).all()
    else:
        rows = conn.execute(q.LATEST_ALL).all()
    return [LatestOut(ticker=r[0], **price_out(r[1:]).model_dump()) for r in rows]


@app.get("/api/v1/stocks/{ticker}/prices", response_model=list[PriceOut], tags=["Ceny"],
         dependencies=[Depends(require_api_key)])
def get_prices(
    ticker: TickerPath,
    start_date: date | None = None,
    end_date: date | None = None,
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
    conn: Connection = Depends(get_conn),
):
    check_range(start_date, end_date)
    rows = conn.execute(
        q.PRICES_HISTORY,
        {"stock_id": get_stock_id(conn, ticker), "start": start_date, "end": end_date, "limit": limit},
    ).all()
    return [price_out(r) for r in reversed(rows)]        # od najstarszej do najnowszej


@app.get("/api/v1/stocks/{ticker}/patterns", response_model=list[PatternOut], tags=["Analiza"],
         dependencies=[Depends(require_api_key)])
def get_patterns(
    ticker: TickerPath,
    start_date: date | None = None,
    end_date: date | None = None,
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
    conn: Connection = Depends(get_conn),
):
    """Wykryte wzorce wzrostu/spadku (zapisane przez collector)."""
    check_range(start_date, end_date)
    rows = conn.execute(
        q.SIGNALS_HISTORY,
        {"stock_id": get_stock_id(conn, ticker), "start": start_date, "end": end_date, "limit": limit},
    ).all()
    return [
        PatternOut(trade_date=d, pattern=PATTERN_NAMES.get(code, f"UNKNOWN_{code}"),
                   value=None if v is None else round(v, 4))
        for d, code, v in rows
    ]


@app.get("/api/v1/stocks/{ticker}/analysis", response_model=AnalysisOut, tags=["Analiza"],
         dependencies=[Depends(require_api_key)])
def stock_analysis(ticker: TickerPath, conn: Connection = Depends(get_conn)):
    """Aktualny stan spółki: trend, RSI, średnie, zmiany % oraz wzorce z ostatniej sesji."""
    stock_id = get_stock_id(conn, ticker)
    rows = conn.execute(q.SELECT_RECENT_BARS,
                        {"stock_id": stock_id, "limit": settings.analysis_window}).all()
    if not rows:
        raise HTTPException(status_code=404, detail="Brak danych dla tej spółki.")

    bars = [Bar(d, from_scaled(o), from_scaled(h), from_scaled(l), from_scaled(c), v)
            for d, o, h, l, c, v in reversed(rows)]
    params = settings.pattern_params
    info = analyse(bars, params)
    active = [PATTERN_NAMES[code] for code, _ in detect_patterns(bars, params)]
    return AnalysisOut(
        ticker=ticker.upper(),
        trade_date=bars[-1].day,
        samples=len(bars),
        data_age_days=max(0, (date.today() - bars[-1].day).days),
        patterns=active,
        **info,
    )
