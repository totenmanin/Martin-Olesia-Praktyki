"""Collector - pobiera dzienne notowania spółek Nasdaq (Yahoo Finance) i zapisuje do bazy.

Jednorazowo:      python -m app.collector            (lub: python -m app.collector AAPL MSFT)
Codziennie sam:   python -m app.collector --daemon   (o godzinie RUN_AT_UTC)
"""
import argparse
import logging
import math
import signal
import threading
import time
from datetime import datetime, timedelta, timezone

from app import queries as q
from app.config import settings
from app.db import get_engine
from app.market import clamp_volume, from_scaled, session_closed, to_scaled
from app.patterns import Bar, detect_patterns

logger = logging.getLogger("collector")
CONTEXT_BARS = 300   # ile poprzednich sesji bierzemy do wykrywania wzorców


def fetch_history(symbol: str):
    """Pobiera historię z Yahoo. Zwraca (lista Bar, nazwa spółki albo None)."""
    import yfinance as yf          # import tutaj, żeby reszta kodu dała się testować bez biblioteki

    ticker = yf.Ticker(symbol)
    # auto_adjust=False: zostają prawdziwe ceny (Close jest skorygowany o splity akcji)
    history = ticker.history(period=settings.history_period, interval="1d", auto_adjust=False)
    bars: list[Bar] = []
    for ts, row in history.iterrows():
        day = ts.date()
        if not session_closed(day):
            continue                                  # pomijamy dzisiejszą, niepełną sesję
        values = [row["Open"], row["High"], row["Low"], row["Close"], row["Volume"]]
        if any(math.isnan(float(v)) for v in values):
            continue
        try:
            o, h, l, c = (to_scaled(v) for v in values[:4])
        except ValueError:
            logger.warning("%s %s: cena poza zakresem - pomijam", symbol, day)
            continue
        if min(o, h, l, c) <= 0:
            continue
        # Do analizy używamy tych samych (zaokrąglonych) liczb, które trafiają do bazy
        bars.append(Bar(day, from_scaled(o), from_scaled(h), from_scaled(l), from_scaled(c),
                        clamp_volume(values[4])))
    return bars


def fetch_name(symbol: str) -> str | None:
    """Pełna nazwa spółki - tylko dla nowych spółek (to osobne, wolniejsze zapytanie)."""
    try:
        import yfinance as yf
        info = yf.Ticker(symbol).get_info()
        name = info.get("shortName") or info.get("longName")
        return name[:100] if name else None
    except Exception as exc:
        logger.info("Brak nazwy dla %s: %r", symbol, exc)
        return None


def scrape_symbol(symbol: str) -> int:
    """Pobiera i zapisuje jedną spółkę (jedna transakcja). Zwraca liczbę przetworzonych sesji."""
    engine = get_engine()
    with engine.connect() as conn:
        known = conn.execute(q.SELECT_STOCK_NAME, {"ticker": symbol}).first()
    name = fetch_name(symbol) if known is None or known[0] is None else None

    bars = fetch_history(symbol)
    if not bars:
        logger.warning("%s: brak danych z Yahoo.", symbol)
        return 0

    params = settings.pattern_params
    with engine.begin() as conn:
        conn.execute(q.INSERT_STOCK, {"ticker": symbol, "name": name})
        stock_id = conn.execute(q.SELECT_STOCK_ID, {"ticker": symbol}).scalar_one()
        last_date = conn.execute(q.SELECT_LAST_DATE, {"stock_id": stock_id}).scalar()

        conn.execute(q.UPSERT_PRICE, [
            {"stock_id": stock_id, "trade_date": b.day,
             "open_price": to_scaled(b.open), "high_price": to_scaled(b.high),
             "low_price": to_scaled(b.low), "close_price": to_scaled(b.close), "volume": b.volume}
            for b in bars
        ])

        # Wzorce liczymy tylko dla nowych sesji (przy pierwszym uruchomieniu - dla całej historii)
        signal_rows = []
        for i, bar in enumerate(bars):
            if last_date is not None and bar.day <= last_date:
                continue
            context = bars[max(0, i - CONTEXT_BARS + 1): i + 1]
            for code, value in detect_patterns(context, params):
                signal_rows.append({"stock_id": stock_id, "trade_date": bar.day,
                                    "pattern": code, "value": value})
        if signal_rows:
            conn.execute(q.INSERT_SIGNAL, signal_rows)

    logger.info("%s: %d sesji, %d nowych wzorców.", symbol, len(bars), len(signal_rows))
    return len(bars)


def run_once(symbols: list[str], stop: threading.Event | None = None) -> None:
    ok = failed = 0
    for symbol in symbols:
        if stop is not None and stop.is_set():
            break
        try:
            scrape_symbol(symbol)
            ok += 1
        except Exception:
            failed += 1
            logger.exception("Błąd przy %s (idę dalej)", symbol)   # jedna spółka nie blokuje reszty
        time.sleep(settings.request_pause_seconds)
    logger.info("Koniec rundy: %d OK, %d z błędem.", ok, failed)


def seconds_until_next_run() -> float:
    hour, minute = (int(x) for x in settings.run_at_utc.split(":"))
    now = datetime.now(timezone.utc)
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return (target - now).total_seconds()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    parser = argparse.ArgumentParser(description="Collector notowań Nasdaq")
    parser.add_argument("symbols", nargs="*", help="np. AAPL MSFT (domyślnie lista z SYMBOLS)")
    parser.add_argument("--daemon", action="store_true", help="uruchamiaj codziennie o RUN_AT_UTC")
    args = parser.parse_args()
    symbols = [s.upper() for s in args.symbols] or settings.symbol_list

    stop = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())

    run_once(symbols, stop)
    while args.daemon and not stop.is_set():
        wait = seconds_until_next_run()
        logger.info("Następne pobranie za %.1f h.", wait / 3600)
        if stop.wait(wait):
            break
        run_once(symbols, stop)


if __name__ == "__main__":
    main()
