"""Generuje nowy klucz API. Użycie: python scripts/make_api_key.py nazwa_klienta"""
import hashlib
import secrets
import sys

name = sys.argv[1] if len(sys.argv) > 1 else "klient"
key = secrets.token_urlsafe(32)
key_hash = hashlib.sha256(key.encode("utf-8")).hexdigest()

print(f"Klucz dla klienta (pokazany tylko raz, przekaż go klientowi):\n  {key}\n")
print("Wpisz do .env w zmiennej API_KEYS (kilka kluczy oddziel przecinkiem):")
print(f"  {name}:{key_hash}")
