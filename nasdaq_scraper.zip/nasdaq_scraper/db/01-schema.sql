CREATE DATABASE IF NOT EXISTS nasdaq_db CHARACTER SET utf8mb4;
USE nasdaq_db;

-- Schemat jak najlzejszy: male typy liczbowe, jeden indeks (klucz glowny) na tabele.
-- Ceny zapisane jako cena * 10000 (INT UNSIGNED, 4 B, dokladnie, bez bledow zaokraglen).

-- Slownik spolek: ticker i nazwa zapisane raz; w notowaniach tylko 2-bajtowe id
CREATE TABLE IF NOT EXISTS stocks (
    id     SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(16)  NOT NULL,
    name   VARCHAR(100) NULL,
    UNIQUE KEY uq_stocks_ticker (ticker)
) ENGINE=InnoDB;

-- Notowania dzienne (OHLCV). Klucz glowny (stock_id, trade_date) = jedyny indeks.
CREATE TABLE IF NOT EXISTS daily_prices (
    stock_id    SMALLINT UNSIGNED NOT NULL,
    trade_date  DATE NOT NULL,
    open_price  INT UNSIGNED NOT NULL,
    high_price  INT UNSIGNED NOT NULL,
    low_price   INT UNSIGNED NOT NULL,
    close_price INT UNSIGNED NOT NULL,
    volume      INT UNSIGNED NOT NULL,
    PRIMARY KEY (stock_id, trade_date)
) ENGINE=InnoDB;

-- Wykryte wzorce wzrostu/spadku (tylko momenty zdarzen).
-- pattern: 1=STREAK_UP 2=STREAK_DOWN 3=SMA_CROSS_UP 4=SMA_CROSS_DOWN 5=BREAKOUT_UP
--   6=BREAKOUT_DOWN 7=BIG_RISE 8=BIG_DROP 9=GAP_UP 10=GAP_DOWN 11=VOLUME_SPIKE
--   12=RSI_OVERBOUGHT 13=RSI_OVERSOLD
CREATE TABLE IF NOT EXISTS signals (
    stock_id   SMALLINT UNSIGNED NOT NULL,
    trade_date DATE NOT NULL,
    pattern    TINYINT UNSIGNED NOT NULL,
    value      FLOAT NULL,
    PRIMARY KEY (stock_id, trade_date, pattern)
) ENGINE=InnoDB;
