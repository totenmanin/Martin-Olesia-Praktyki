#!/bin/bash
# Dwóch użytkowników o minimalnych uprawnieniach:
#  - nasdaq_collector: SELECT, INSERT, UPDATE (upsert notowań)
#  - nasdaq_api_ro:    wyłącznie SELECT
set -e
mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" <<EOSQL
CREATE USER IF NOT EXISTS 'nasdaq_collector'@'%' IDENTIFIED BY '${COLLECTOR_DB_PASSWORD}';
GRANT SELECT, INSERT, UPDATE ON nasdaq_db.* TO 'nasdaq_collector'@'%';
CREATE USER IF NOT EXISTS 'nasdaq_api_ro'@'%' IDENTIFIED BY '${API_DB_PASSWORD}';
GRANT SELECT ON nasdaq_db.* TO 'nasdaq_api_ro'@'%';
FLUSH PRIVILEGES;
EOSQL
