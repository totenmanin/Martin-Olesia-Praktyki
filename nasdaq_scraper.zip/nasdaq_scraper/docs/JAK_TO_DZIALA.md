# Jak to działa (ściąga)

## Przepływ danych
1. `collector.py` dla każdej spółki pobiera z Yahoo historię dzienną (domyślnie rok).
2. Odrzuca niepełną, dzisiejszą sesję i dane z brakami.
3. Zapisuje notowania (`INSERT ... ON DUPLICATE KEY UPDATE`), więc ponowne uruchomienie niczego nie dubluje.
4. Dla nowych sesji `patterns.py` sprawdza wzorce; zdarzenia trafiają do `signals`.
5. `api.py` tylko czyta bazę i zwraca JSON; wymaga klucza API.

## Pliki
- `app/patterns.py` - czysta logika wzorców (bez bazy i internetu, łatwa do testów).
- `app/market.py` - przeliczanie cen na liczby całkowite, sprawdzanie czy sesja zakończona.
- `app/queries.py` - WSZYSTKIE zapytania SQL w jednym miejscu.
- `app/collector.py`, `app/api.py`, `app/security.py`, `app/schemas.py`, `app/config.py`, `app/db.py`.
- `db/01-schema.sql` (tabele), `db/02-users.sh` (użytkownicy w Dockerze), `db/nasdaq.sql` (wszystko do importu w XAMPP).

## Pytania, które może zadać opiekun
- *Dlaczego ceny jako liczby całkowite?* 4 B zamiast 6 B i brak błędów zaokrągleń typowych dla liczb zmiennoprzecinkowych.
- *Dlaczego brak kolumny `id` i klucza obcego?* Para `(stock_id, trade_date)` jednoznacznie identyfikuje sesję, a InnoDB trzyma dane posortowane po kluczu głównym; mniej indeksów = mniej miejsca i szybszy zapis.
- *Po co upsert?* Po splicie akcji Yahoo koryguje historyczne ceny; nadpisanie okresu utrzymuje spójność.
- *Dlaczego pomijamy dzisiejszą sesję?* Przed zamknięciem giełdy świeca jest niepełna i dawałaby fałszywe wzorce.
- *Dlaczego dwóch użytkowników bazy?* API nie potrzebuje zapisu, więc nawet po jego włamaniu nie da się zmienić danych.
- *Co oznacza RSI / SMA?* RSI (0-100) porównuje siłę ostatnich wzrostów i spadków; SMA to zwykła średnia z N sesji, a przecięcie szybkiej z wolną sygnalizuje zmianę trendu.
